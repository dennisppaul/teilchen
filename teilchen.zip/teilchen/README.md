teilchen
========

* *teilchen* is a simple physics library based on particles, forces, constraints and behaviors. 
* *teilchen* is also a collection of a variety of concepts useful for modeling with virtual physics and behaviors. nothing new nothing fancy, except maybe for the combination of forces ( *external forces* ) and behavior ( *internal forces* ).
* *teilchen* is also a [processing.org](http://processing.org "Processing.org")-style library.
* *teilchen* is a german word and the synonym for *Partikel* which translates to the english *particle*  )

## versions

### 002 20160423

* updated for processing3
* now using PVector for linear algebra
* removed dependency on *mathematik*

### 001 20150228

* initial release
