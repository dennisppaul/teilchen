package teilchen.examples;

import processing.core.PApplet;
import processing.core.PVector;
import teilchen.Particle;
import teilchen.Physics;
import teilchen.force.Gravity;
import teilchen.force.IForce;
import teilchen.force.Spring;
import teilchen.force.TearableSpring;
import teilchen.integration.RungeKutta;

public class SketchLessonX12_TearableSpring extends PApplet {

    /*
     * this sketch demonstrates how to use `TearableSprings` a variation of the normal spring that
     * tears if stretched beyond a certain length. drag particles to tear spring mesh.
     *
     * press mouse to drag particle and tear spring.
     */

    private static final int GRID_HEIGHT = 24;
    private static final int GRID_WIDTH = 32;
    private Particle mParticleSelected = null;
    private final Particle[][] mParticles = new Particle[GRID_WIDTH][GRID_HEIGHT];
    private Physics mPhysics;

    public void settings() {
        size(640, 480, P3D);
    }

    public void setup() {
        mPhysics = new Physics();

        /* select `RungeKutta` for integration as it can handle multiple connected springs better */
        RungeKutta mIntegrator = new RungeKutta();
        mPhysics.setIntegratorRef(mIntegrator);

        mPhysics.add(new Gravity(0, 0.981f, 0));

        /* create particles */
        final PVector mTranslate = new PVector().set(width / 4.0f, height / 4.0f);
        for (int x = 0; x < mParticles.length; x++) {
            for (int y = 0; y < mParticles[x].length; y++) {
                final Particle p = mPhysics.makeParticle();
                p.mass(0.01f);
                p.position().set(x, y);
                p.position().mult(10.0f);
                p.position().add(mTranslate);
                mParticles[x][y] = p;
            }
        }

        /* connect particles with tearable spring */
        for (int x = 0; x < GRID_WIDTH; x++) {
            for (int y = 0; y < GRID_HEIGHT; y++) {
                final Particle p0 = mParticles[x][y];
                if (x < GRID_WIDTH - 1) {
                    final Particle p1 = mParticles[x + 1][y];
                    createSpring(p0, p1);
                }
                if (y < GRID_HEIGHT - 1) {
                    final Particle p2 = mParticles[x][y + 1];
                    createSpring(p0, p2);
                }
            }
        }

        /*  fix corner particles */
        mParticles[0][0].fixed(true);
        mParticles[GRID_WIDTH - 1][0].fixed(true);
        mParticles[0][GRID_HEIGHT - 1].fixed(true);
        mParticles[GRID_WIDTH - 1][GRID_HEIGHT - 1].fixed(true);
    }

    public void draw() {
        if (mParticleSelected != null) {
            /* not that it is better to perform all *direct* particle manipulations before `step`
            is called */
            mParticleSelected.position().set(mouseX, mouseY);
        }

        /* in systems with a lot of *tension* it is sometimes necessary to calculate steps in
        smaller fractions. in this case 5 times per frame */
        mPhysics.step(1.0f / frameRate, 5);

        /* draw */
        background(255);

        noStroke();
        fill(0);
        for (Particle p : mPhysics.particles()) {
            final float mParticleSize = 3;
            ellipse(p.position().x, p.position().y, mParticleSize, mParticleSize);
        }

        stroke(0, 127);
        noFill();
        for (IForce f : mPhysics.forces()) {
            if (f instanceof Spring) {
                Spring s = (Spring) f;
                drawSpring(s);
            }
        }

        if (mParticleSelected != null) {
            noFill();
            stroke(0);
            final float mParticleSize = 5 * 3;
            ellipse(mParticleSelected.position().x, mParticleSelected.position().y, mParticleSize, mParticleSize);
        }
    }

    public void mousePressed() {
        mParticleSelected = teilchen.util.Util.findParticleByProximity(mPhysics, mouseX, mouseY, 0, 20);
    }

    public void mouseReleased() {
        mParticleSelected = null;
    }

    private void createSpring(Particle p0, Particle p1) {
        TearableSpring s = new TearableSpring(p0, p1);
        s.tear_distance(40);
        s.strength(20.0f);
        s.damping(1.0f);
        mPhysics.add(s);
    }

    private void drawSpring(Spring s) {
        line(s.a().position().x,
             s.a().position().y,
             s.a().position().z,
             s.b().position().x,
             s.b().position().y,
             s.b().position().z);
    }

    public static void main(String[] args) {
        PApplet.main(SketchLessonX12_TearableSpring.class.getName());
    }
}
