/*
 * Teilchen
 *
 * This file is part of the *teilchen* library (https://github.com/dennisppaul/teilchen).
 * Copyright (c) 2024 Dennis P Paul.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * {@link http://www.gnu.org/licenses/lgpl.html}
 *
 */
package teilchen.behavior;

import processing.core.PVector;
import teilchen.BehaviorParticle;
import teilchen.util.Random;

import static processing.core.PVector.cross;
import static processing.core.PVector.mult;
import static teilchen.util.Util.isNaN;

public class Wander implements IBehavior {

    static final long serialVersionUID = 4957162698340669663L;
    private boolean mActive;
    private float mCurrentSteeringStrength;
    private final PVector mForce;
    private final Random mRandom;
    private float mSteeringOffset;
    private float mSteeringStrength;
    private final PVector mUpVector;
    private float mWeight;

    public Wander() {
        mRandom = new Random();

        mForce = new PVector();
        mSteeringStrength = 10f;
        mSteeringOffset = 5f;

        mUpVector = new PVector(0, 0, 1);

        mWeight = 1;
        mActive = true;
    }

    public boolean active() {
        return mActive;
    }

    public void active(boolean pActive) {
        mActive = pActive;
    }

    public PVector force() {
        return mForce;
    }

    public float weight() {
        return mWeight;
    }

    public void weight(float pWeight) {
        mWeight = pWeight;
    }

    public void update(float pDeltaTime, BehaviorParticle pParent) {
        if (mActive && pParent.velocity().mag() > 0) {
            mCurrentSteeringStrength += mRandom.getFloat(-0.5f, 0.5f) * mSteeringOffset;
            mCurrentSteeringStrength = Math.max(Math.min(mCurrentSteeringStrength, mSteeringStrength),
                                                -mSteeringStrength);

            final PVector mWanderTarget = new PVector();
            cross(mUpVector, pParent.velocity(), mWanderTarget);
            mWanderTarget.normalize();
            mWanderTarget.mult(mCurrentSteeringStrength);
            if (isNaN(mWanderTarget)) {
                mForce.set(0, 0, 0);
            } else {
                mult(mWanderTarget, mWeight, mForce);
            }
        } else {
            mForce.set(0, 0, 0);
        }
    }

    public PVector upvector() {
        return mUpVector;
    }

    public float steeringstrength() {
        return mSteeringStrength;
    }

    public void steeringstrength(final float pSteeringStrength) {
        mSteeringStrength = pSteeringStrength;
    }

    public float steeringoffset() {
        return mSteeringOffset;
    }

    public void steeringoffset(final float pSteeringOffset) {
        mSteeringOffset = pSteeringOffset;
    }
}
