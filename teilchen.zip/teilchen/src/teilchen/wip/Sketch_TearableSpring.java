package teilchen.wip;

import processing.core.PApplet;

public class Sketch_TearableSpring extends PApplet {

    public void settings() {
    }

    public void setup() {
    }

    public void draw() {
    }

    public static void main(String[] args) {
        PApplet.main(Sketch_TearableSpring.class.getName());
    }
}
