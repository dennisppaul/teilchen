package teilchen.wip;

import processing.core.PApplet;

public class SketchNonIntersectingStructures extends PApplet {

    public void settings() {
    }

    public void setup() {
    }

    public void draw() {
    }

    public static void main(String[] args) {
        PApplet.main(SketchNonIntersectingStructures.class.getName());
    }
}
