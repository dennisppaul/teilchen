package teilchen.wip;

import processing.core.PApplet;

public class Sketch_MuscleSprings extends PApplet {

    public void settings() {
    }

    public void setup() {
    }

    public void draw() {
    }

    public static void main(String[] args) {
        PApplet.main(Sketch_MuscleSprings.class.getName());
    }
}
